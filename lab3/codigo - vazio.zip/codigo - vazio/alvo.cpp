#include "alvo.h"
#include <math.h>

void Alvo::DesenhaCirc(GLint radius, GLfloat R, GLfloat G, GLfloat B)
{

}

void Alvo::DesenhaAlvo(GLfloat x, GLfloat y)
{
 
}

void Alvo::Recria(GLfloat x, GLfloat y)
{

}

bool Alvo::Atingido(Tiro *tiro)
{

}
