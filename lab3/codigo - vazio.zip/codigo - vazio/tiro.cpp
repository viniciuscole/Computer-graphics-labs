#include "tiro.h"
#include <math.h>
#define DISTANCIA_MAX 500

void Tiro::DesenhaCirc(GLint radius, GLfloat R, GLfloat G, GLfloat B)
{

}

void Tiro::DesenhaTiro(GLfloat x, GLfloat y)
{

}

void Tiro::Move()
{

}

bool Tiro::Valido()
{

}
